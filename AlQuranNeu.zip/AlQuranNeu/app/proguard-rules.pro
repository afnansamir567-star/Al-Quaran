# Room/Compose ship consumer rules. Nothing extra needed.
