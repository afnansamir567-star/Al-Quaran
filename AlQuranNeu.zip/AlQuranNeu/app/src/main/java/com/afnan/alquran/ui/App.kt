package com.afnan.alquran.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.afnan.alquran.AppViewModel

@Composable
fun AlQuranApp(vm: AppViewModel) {
    NeuTheme(vm.dark) {
        Box(Modifier.fillMaxSize().systemBarsPadding()) {
            when (vm.ready) {
                null -> Unit
                false -> DownloadScreen(vm)
                true -> MainShell(vm)
            }
        }
    }
}

@Composable
private fun MainShell(vm: AppViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var readerPage by rememberSaveable { mutableStateOf<Int?>(null) }

    val rp = readerPage
    if (rp != null) {
        ReaderScreen(vm, rp) { readerPage = null }
        return
    }
    val open: (Int) -> Unit = { readerPage = it }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> HomeScreen(vm, open)
                1 -> SurahScreen(vm, open)
                2 -> JuzScreen(vm, open)
                3 -> BookmarkScreen(vm, open)
                else -> SettingsScreen(vm)
            }
        }
        NeuBottomBar(tab) { tab = it }
    }
}
