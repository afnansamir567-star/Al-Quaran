package com.afnan.alquran.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Text source: api.alquran.cloud (editions: quran-uthmani + bn.bengali).
 * Downloaded ONCE, stored in Room, then the app works fully offline.
 */
class QuranRepository(private val dao: QuranDao) {

    companion object {
        const val TOTAL_AYAHS = 6236
        const val TOTAL_PAGES = 604
        private const val URL_ARABIC = "https://api.alquran.cloud/v1/quran/quran-uthmani"
        private const val URL_BENGALI = "https://api.alquran.cloud/v1/quran/bn.bengali"
        private const val BISMILLAH_WORDS = 4
    }

    suspend fun isReady(): Boolean = dao.ayahCount() >= TOTAL_AYAHS

    suspend fun download(onProgress: (Float, Int) -> Unit) = withContext(Dispatchers.IO) {
        // stage ids: 0 = arabic, 1 = bengali, 2 = saving
        onProgress(0.05f, 0)
        val arabic = JSONObject(fetch(URL_ARABIC)).getJSONObject("data").getJSONArray("surahs")
        onProgress(0.45f, 1)
        val bengali = JSONObject(fetch(URL_BENGALI)).getJSONObject("data").getJSONArray("surahs")
        onProgress(0.85f, 2)

        val bnById = HashMap<Int, String>(7000)
        for (i in 0 until bengali.length()) {
            val ayahs = bengali.getJSONObject(i).getJSONArray("ayahs")
            for (j in 0 until ayahs.length()) {
                val a = ayahs.getJSONObject(j)
                bnById[a.getInt("number")] = a.getString("text")
            }
        }

        val surahList = ArrayList<SurahEntity>(114)
        val ayahList = ArrayList<AyahEntity>(TOTAL_AYAHS)
        for (i in 0 until arabic.length()) {
            val s = arabic.getJSONObject(i)
            val sNo = s.getInt("number")
            val ayahs = s.getJSONArray("ayahs")
            surahList += SurahEntity(
                number = sNo,
                name = s.getString("name"),
                englishName = s.getString("englishName"),
                englishTranslation = s.getString("englishNameTranslation"),
                ayahCount = ayahs.length(),
                revelationType = s.getString("revelationType")
            )
            for (j in 0 until ayahs.length()) {
                val a = ayahs.getJSONObject(j)
                val id = a.getInt("number")
                val inSurah = a.getInt("numberInSurah")
                ayahList += AyahEntity(
                    id = id,
                    surah = sNo,
                    numberInSurah = inSurah,
                    arabic = stripBismillah(a.getString("text"), sNo, inSurah),
                    bengali = bnById[id].orEmpty(),
                    juz = a.getInt("juz"),
                    page = a.getInt("page"),
                    sajda = a.opt("sajda").let { it == true || it is JSONObject }
                )
            }
        }
        check(ayahList.size == TOTAL_AYAHS) { "Unexpected ayah count: ${ayahList.size}" }
        dao.replaceAll(surahList, ayahList)
        onProgress(1f, 2)
    }

    /**
     * The uthmani edition glues the Bismillah onto ayah 1 of every surah except
     * Al-Fatiha (where it IS ayah 1) and At-Tawbah (none). The UI shows the
     * Bismillah as a separate header, so cut the first 4 words off.
     */
    private fun stripBismillah(text: String, surah: Int, inSurah: Int): String {
        if (inSurah != 1 || surah == 1 || surah == 9) return text
        val words = text.trim().split(' ')
        return if (words.size > BISMILLAH_WORDS) words.drop(BISMILLAH_WORDS).joinToString(" ") else text
    }

    private fun fetch(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 20_000
            c.readTimeout = 60_000
            c.setRequestProperty("Accept", "application/json")
            if (c.responseCode != 200) error("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    suspend fun pageInfo(page: Int): Pair<SurahEntity, Int>? {
        val ayahs = dao.ayahsOnPage(page)
        val first = ayahs.firstOrNull() ?: return null
        val s = dao.surahsByNumbers(listOf(first.surah)).firstOrNull() ?: return null
        return s to first.juz
    }

    suspend fun pageAyahs(page: Int): List<AyahEntity> = dao.ayahsOnPage(page)

    suspend fun surahMap(numbers: List<Int>): Map<Int, SurahEntity> =
        dao.surahsByNumbers(numbers).associateBy { it.number }
}
