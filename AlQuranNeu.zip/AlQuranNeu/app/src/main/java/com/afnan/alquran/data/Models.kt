package com.afnan.alquran.data

import androidx.room.ColumnInfo
import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "surah")
data class SurahEntity(
    @PrimaryKey val number: Int,
    val name: String,
    val englishName: String,
    val englishTranslation: String,
    val ayahCount: Int,
    val revelationType: String
)

@Entity(
    tableName = "ayah",
    indices = [Index("page"), Index("surah"), Index("juz")]
)
data class AyahEntity(
    @PrimaryKey val id: Int,          // global ayah number 1..6236
    val surah: Int,
    val numberInSurah: Int,
    val arabic: String,
    val bengali: String,
    val juz: Int,
    val page: Int,                    // Madani mushaf page 1..604
    val sajda: Boolean
)

/** One bookmark per mushaf page. */
@Entity(tableName = "bookmark")
data class BookmarkEntity(
    @PrimaryKey val page: Int,
    val surah: Int,
    val createdAt: Long
)

data class SurahRow(
    @Embedded val surah: SurahEntity,
    @ColumnInfo(name = "startPage") val startPage: Int
)

data class JuzRow(
    val juz: Int,
    val startPage: Int
)
