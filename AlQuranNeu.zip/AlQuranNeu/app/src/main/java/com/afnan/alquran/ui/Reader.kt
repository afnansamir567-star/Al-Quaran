package com.afnan.alquran.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.afnan.alquran.AppViewModel
import com.afnan.alquran.data.AyahEntity
import com.afnan.alquran.data.QuranRepository
import com.afnan.alquran.data.SurahEntity

private const val BISMILLAH = "بِسْمِ ٱللَّهِ ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ"

@Composable
fun ReaderScreen(vm: AppViewModel, startPage: Int, onBack: () -> Unit) {
    val p = LocalPalette.current
    BackHandler(onBack = onBack)

    val pager = rememberPagerState(
        initialPage = (startPage - 1).coerceIn(0, QuranRepository.TOTAL_PAGES - 1),
        pageCount = { QuranRepository.TOTAL_PAGES }
    )
    val page = pager.currentPage + 1

    LaunchedEffect(pager.settledPage) { vm.saveLastPage(pager.settledPage + 1) }

    // keep screen awake while reading
    val view = LocalView.current
    DisposableEffect(vm.keepScreenOn) {
        view.keepScreenOn = vm.keepScreenOn
        onDispose { view.keepScreenOn = false }
    }

    var title by remember { mutableStateOf("") }
    LaunchedEffect(page) {
        title = vm.repo.pageInfo(page)?.let { (s, j) -> "${s.englishName} · ${S.juzWord} ${j.toBn()}" } ?: ""
    }
    val bookmarked by remember(page) { vm.isBookmarked(page) }.collectAsState(false)

    Column(Modifier.fillMaxSize()) {
        // top bar
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NeuBox(Modifier.size(46.dp), radius = 23.dp, depth = 5.dp, onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, null, tint = p.text, modifier = Modifier.align(Alignment.Center))
            }
            Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text(title, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text("${S.page} ${page.toBn()} / ${QuranRepository.TOTAL_PAGES.toBn()}", color = p.sub, fontSize = 12.sp)
            }
            NeuBox(Modifier.size(46.dp), radius = 23.dp, depth = 5.dp, inset = bookmarked, onClick = { vm.toggleBookmark(page, bookmarked) }) {
                Icon(
                    if (bookmarked) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder, null,
                    tint = p.accent, modifier = Modifier.align(Alignment.Center)
                )
            }
        }

        // Mushaf pages swipe right-to-left, so reverse the pager.
        HorizontalPager(
            state = pager,
            reverseLayout = true,
            beyondViewportPageCount = 1,
            modifier = Modifier.weight(1f)
        ) { index ->
            QuranPage(vm, index + 1)
        }
    }
}

private sealed interface Block {
    data class Header(val surah: SurahEntity) : Block
    data object Bismillah : Block
    data class Run(val ayahs: List<AyahEntity>) : Block
}

@Composable
private fun QuranPage(vm: AppViewModel, page: Int) {
    val p = LocalPalette.current
    var blocks by remember(page) { mutableStateOf<List<Block>?>(null) }

    LaunchedEffect(page) {
        val ayahs = vm.repo.pageAyahs(page)
        val names = vm.repo.surahMap(ayahs.map { it.surah }.distinct())
        val out = ArrayList<Block>()
        var cur = ArrayList<AyahEntity>()
        fun flush() { if (cur.isNotEmpty()) { out.add(Block.Run(cur)); cur = ArrayList() } }
        for (a in ayahs) {
            if (a.numberInSurah == 1) {
                flush()
                names[a.surah]?.let { out.add(Block.Header(it)) }
                if (a.surah != 1 && a.surah != 9) out.add(Block.Bismillah)
            }
            cur.add(a)
        }
        flush()
        blocks = out
    }

    val list = blocks
    if (list == null) {
        Box(Modifier.fillMaxSize())
        return
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        list.forEach { b ->
            when (b) {
                is Block.Header -> NeuBox(Modifier.fillMaxWidth().height(64.dp), radius = 18.dp, depth = 5.dp, inset = true) {
                    Row(Modifier.fillMaxSize().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(b.surah.englishName, color = p.sub, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                            Text(b.surah.name, color = p.accent, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Block.Bismillah -> CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Text(BISMILLAH, color = p.text, fontSize = (vm.fontSize * 0.9f).sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
                is Block.Run -> if (vm.showTranslation) {
                    b.ayahs.forEach { a -> AyahCard(vm, a) }
                } else {
                    FlowingText(vm, b.ayahs)
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun FlowingText(vm: AppViewModel, ayahs: List<AyahEntity>) {
    val p = LocalPalette.current
    val size = vm.fontSize
    val text = buildAnnotatedString {
        ayahs.forEach { a ->
            append(a.arabic.trim())
            append(" ")
            withStyle(SpanStyle(color = p.accent, fontSize = (size * 0.75f).sp)) {
                append("\uFD3F${a.numberInSurah.toArabicDigits()}\uFD3E")
            }
            append(" ")
        }
    }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Text(
            text, color = p.text, fontSize = size.sp, lineHeight = (size * 2.0f).sp,
            textAlign = TextAlign.Justify, modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun AyahCard(vm: AppViewModel, a: AyahEntity) {
    val p = LocalPalette.current
    NeuBox(Modifier.fillMaxWidth(), radius = 20.dp, depth = 6.dp) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                NeuBox(Modifier.size(34.dp), radius = 17.dp, depth = 3.dp, inset = true) {
                    Text(a.numberInSurah.toBn(), color = p.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Center))
                }
            }
            Spacer(Modifier.height(12.dp))
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Text(
                    a.arabic.trim(), color = p.text, fontSize = vm.fontSize.sp,
                    lineHeight = (vm.fontSize * 1.9f).sp, modifier = Modifier.fillMaxWidth()
                )
            }
            if (a.bengali.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                Text(a.bengali, color = p.sub, fontSize = 15.sp, lineHeight = 23.sp)
            }
        }
    }
}
