package com.afnan.alquran.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
abstract class QuranDao {
    @Query("SELECT COUNT(*) FROM ayah")
    abstract suspend fun ayahCount(): Int

    @Query(
        "SELECT s.*, (SELECT MIN(page) FROM ayah a WHERE a.surah = s.number) AS startPage " +
            "FROM surah s ORDER BY s.number"
    )
    abstract fun surahs(): Flow<List<SurahRow>>

    @Query("SELECT juz, MIN(page) AS startPage FROM ayah GROUP BY juz ORDER BY juz")
    abstract fun juzs(): Flow<List<JuzRow>>

    @Query("SELECT * FROM ayah WHERE page = :page ORDER BY id")
    abstract suspend fun ayahsOnPage(page: Int): List<AyahEntity>

    @Query("SELECT * FROM surah WHERE number IN (:numbers)")
    abstract suspend fun surahsByNumbers(numbers: List<Int>): List<SurahEntity>

    @Query("SELECT * FROM bookmark ORDER BY createdAt DESC")
    abstract fun bookmarks(): Flow<List<BookmarkEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM bookmark WHERE page = :page)")
    abstract fun isBookmarked(page: Int): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insertSurahs(list: List<SurahEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insertAyahs(list: List<AyahEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insertBookmark(b: BookmarkEntity)

    @Query("DELETE FROM bookmark WHERE page = :page")
    abstract suspend fun deleteBookmark(page: Int)

    @Query("DELETE FROM ayah")
    abstract suspend fun clearAyahs()

    @Query("DELETE FROM surah")
    abstract suspend fun clearSurahs()

    @Transaction
    open suspend fun replaceAll(surahs: List<SurahEntity>, ayahs: List<AyahEntity>) {
        clearAyahs()
        clearSurahs()
        insertSurahs(surahs)
        // chunked so a single statement never gets huge
        ayahs.chunked(500).forEach { insertAyahs(it) }
    }
}

@Database(
    entities = [SurahEntity::class, AyahEntity::class, BookmarkEntity::class],
    version = 1,
    exportSchema = false
)
abstract class QuranDb : RoomDatabase() {
    abstract fun dao(): QuranDao

    companion object {
        @Volatile private var instance: QuranDb? = null
        fun get(context: Context): QuranDb = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext, QuranDb::class.java, "alquran.db"
            ).build().also { instance = it }
        }
    }
}
