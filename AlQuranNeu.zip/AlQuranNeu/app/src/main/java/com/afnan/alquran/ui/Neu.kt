package com.afnan.alquran.ui

import android.graphics.Paint as APaint
import android.graphics.Path as APath
import android.graphics.RectF
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

@Immutable
class NeuPalette(
    val bg: Color,
    val light: Color,   // highlight shadow (top-left)
    val dark: Color,    // dark shadow (bottom-right)
    val text: Color,
    val sub: Color,
    val accent: Color
)

val LightPalette = NeuPalette(
    bg = Color(0xFFE3E8EF), light = Color(0xFFFFFFFF), dark = Color(0xFFA9B6C9),
    text = Color(0xFF2A3342), sub = Color(0xFF66748A), accent = Color(0xFF1F8A6A)
)
val DarkPalette = NeuPalette(
    bg = Color(0xFF2A2E35), light = Color(0xFF363C46), dark = Color(0xFF1C1F24),
    text = Color(0xFFE8ECF2), sub = Color(0xFF9AA5B5), accent = Color(0xFF4CD6A3)
)
val LocalPalette = staticCompositionLocalOf { LightPalette }

@Composable
fun NeuTheme(dark: Boolean, content: @Composable () -> Unit) {
    val p = if (dark) DarkPalette else LightPalette
    val view = LocalView.current
    SideEffect {
        val window = (view.context as? android.app.Activity)?.window ?: return@SideEffect
        val c = WindowCompat.getInsetsController(window, view)
        c.isAppearanceLightStatusBars = !dark
        c.isAppearanceLightNavigationBars = !dark
    }
    CompositionLocalProvider(LocalPalette provides p) {
        Box(Modifier.fillMaxSize().background(p.bg)) { content() }
    }
}

/** Soft extruded surface: light shadow top-left, dark shadow bottom-right. */
fun Modifier.neuRaised(radius: Dp = 20.dp, depth: Dp = 8.dp): Modifier = composed {
    val p = LocalPalette.current
    drawBehind {
        val r = radius.toPx()
        val d = depth.toPx()
        drawIntoCanvas { cv ->
            val c = cv.nativeCanvas
            val rect = RectF(0f, 0f, size.width, size.height)
            val paint = APaint(APaint.ANTI_ALIAS_FLAG).apply { color = p.bg.toArgb() }
            paint.setShadowLayer(d * 1.3f, -d, -d, p.light.toArgb())
            c.drawRoundRect(rect, r, r, paint)
            paint.setShadowLayer(d * 1.3f, d, d, p.dark.toArgb())
            c.drawRoundRect(rect, r, r, paint)
        }
    }
}

/** Pressed-in surface: shadows drawn on the inside edges. */
fun Modifier.neuInset(radius: Dp = 18.dp, depth: Dp = 6.dp): Modifier = composed {
    val p = LocalPalette.current
    drawBehind {
        val r = radius.toPx()
        val d = depth.toPx()
        drawIntoCanvas { cv ->
            val c = cv.nativeCanvas
            val w = size.width
            val h = size.height
            val rect = RectF(0f, 0f, w, h)
            val fill = APaint(APaint.ANTI_ALIAS_FLAG).apply { color = p.bg.toArgb() }
            c.drawRoundRect(rect, r, r, fill)

            val clip = APath().apply { addRoundRect(rect, r, r, APath.Direction.CW) }
            val frame = APath().apply {
                fillType = APath.FillType.EVEN_ODD
                addRect(-w, -h, w * 2, h * 2, APath.Direction.CW)
                addRoundRect(rect, r, r, APath.Direction.CW)
            }
            c.save()
            c.clipPath(clip)
            val sp = APaint(APaint.ANTI_ALIAS_FLAG).apply { color = p.bg.toArgb() }
            sp.setShadowLayer(d * 1.2f, d, d, p.dark.toArgb())
            c.drawPath(frame, sp)
            sp.setShadowLayer(d * 1.2f, -d, -d, p.light.toArgb())
            c.drawPath(frame, sp)
            c.restore()
        }
    }
}

/** Generic neumorphic container. Becomes inset while pressed. */
@Composable
fun NeuBox(
    modifier: Modifier = Modifier,
    radius: Dp = 20.dp,
    depth: Dp = 7.dp,
    inset: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val surface = if (inset || pressed) Modifier.neuInset(radius, depth * 0.8f) else Modifier.neuRaised(radius, depth)
    val click = if (onClick != null) Modifier.clickable(interactionSource = src, indication = null, onClick = onClick) else Modifier
    Box(
        modifier = modifier.then(surface).clip(RoundedCornerShape(radius)).then(click),
        content = content
    )
}

@Composable
fun NeuSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPalette.current
    val x by animateDpAsState(if (checked) 26.dp else 0.dp, label = "knob")
    NeuBox(
        modifier = Modifier.size(width = 58.dp, height = 32.dp),
        radius = 16.dp, depth = 4.dp, inset = true,
        onClick = { onChange(!checked) }
    ) {
        Box(
            Modifier.padding(3.dp).offset(x = x).size(26.dp)
                .align(Alignment.CenterStart)
                .neuRaised(13.dp, 3.dp)
                .background(if (checked) p.accent else p.bg, CircleShape)
        )
    }
}
