package com.afnan.alquran

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.afnan.alquran.data.BookmarkEntity
import com.afnan.alquran.data.Prefs
import com.afnan.alquran.data.QuranDb
import com.afnan.alquran.data.QuranRepository
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = QuranDb.get(app).dao()
    val repo = QuranRepository(dao)
    private val prefs = Prefs(app)

    // null = still checking, false = needs download, true = ready
    var ready by mutableStateOf<Boolean?>(null); private set

    var downloading by mutableStateOf(false); private set
    var dlProgress by mutableFloatStateOf(0f); private set
    var dlStage by mutableIntStateOf(0); private set
    var dlError by mutableStateOf<String?>(null); private set

    var dark by mutableStateOf(prefs.dark); private set
    var showTranslation by mutableStateOf(prefs.showTranslation); private set
    var fontSize by mutableFloatStateOf(prefs.fontSize); private set
    var keepScreenOn by mutableStateOf(prefs.keepScreenOn); private set
    var lastPage by mutableIntStateOf(prefs.lastPage); private set

    val surahs = dao.surahs()
    val juzs = dao.juzs()
    val bookmarks = dao.bookmarks()
    fun isBookmarked(page: Int) = dao.isBookmarked(page)

    init {
        viewModelScope.launch { ready = repo.isReady() }
    }

    fun startDownload() {
        if (downloading) return
        downloading = true
        dlError = null
        viewModelScope.launch {
            try {
                repo.download { p, stage -> dlProgress = p; dlStage = stage }
                ready = true
            } catch (e: Exception) {
                dlError = e.message ?: e.javaClass.simpleName
            } finally {
                downloading = false
            }
        }
    }

    fun redownload() {
        ready = false
        startDownload()
    }

    fun setDark(v: Boolean) { dark = v; prefs.dark = v }
    fun setTranslation(v: Boolean) { showTranslation = v; prefs.showTranslation = v }
    fun setFontSize(v: Float) { fontSize = v; prefs.fontSize = v }
    fun setKeepScreenOn(v: Boolean) { keepScreenOn = v; prefs.keepScreenOn = v }
    fun saveLastPage(p: Int) { lastPage = p; prefs.lastPage = p }

    fun toggleBookmark(page: Int, currently: Boolean) {
        viewModelScope.launch {
            if (currently) {
                dao.deleteBookmark(page)
            } else {
                val info = repo.pageInfo(page)
                dao.insertBookmark(BookmarkEntity(page, info?.first?.number ?: 0, System.currentTimeMillis()))
            }
        }
    }

    fun removeBookmark(page: Int) {
        viewModelScope.launch { dao.deleteBookmark(page) }
    }
}
