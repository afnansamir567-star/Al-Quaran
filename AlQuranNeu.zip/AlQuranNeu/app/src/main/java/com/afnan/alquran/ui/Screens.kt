package com.afnan.alquran.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.CompositionLocalProvider
import com.afnan.alquran.AppViewModel
import com.afnan.alquran.data.QuranRepository
import com.afnan.alquran.data.SurahEntity

@Composable
private fun Header(title: String, subtitle: String? = null) {
    val p = LocalPalette.current
    Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp)) {
        Text(title, color = p.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        if (subtitle != null) Text(subtitle, color = p.sub, fontSize = 13.sp)
    }
}

// ───────────────────────── Download / first run ─────────────────────────

@Composable
fun DownloadScreen(vm: AppViewModel) {
    val p = LocalPalette.current
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        NeuBox(Modifier.size(110.dp), radius = 55.dp, depth = 10.dp) {
            Icon(Icons.Rounded.MenuBook, null, tint = p.accent, modifier = Modifier.size(52.dp).align(Alignment.Center))
        }
        Spacer(Modifier.height(32.dp))
        Text(S.dlTitle, color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text(S.dlBody, color = p.sub, fontSize = 14.sp, lineHeight = 21.sp)
        Spacer(Modifier.height(32.dp))

        if (vm.downloading) {
            NeuBox(Modifier.fillMaxWidth().height(22.dp), radius = 11.dp, depth = 4.dp, inset = true) {
                Box(
                    Modifier.padding(4.dp)
                        .fillMaxWidth(vm.dlProgress.coerceIn(0.05f, 1f))
                        .fillMaxSize()
                        .background(p.accent, RoundedCornerShape(7.dp))
                )
            }
            Spacer(Modifier.height(12.dp))
            Text(S.dlStages[vm.dlStage.coerceIn(0, 2)], color = p.sub, fontSize = 13.sp)
        } else {
            vm.dlError?.let {
                Text("${S.dlError}: $it", color = p.accent, fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
            }
            NeuBox(Modifier.fillMaxWidth().height(56.dp), radius = 28.dp, onClick = { vm.startDownload() }) {
                Text(
                    if (vm.dlError == null) S.dlStart else S.dlRetry,
                    color = p.accent, fontWeight = FontWeight.SemiBold, fontSize = 16.sp,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        }
    }
}

// ───────────────────────── Home ─────────────────────────

@Composable
fun HomeScreen(vm: AppViewModel, openReader: (Int) -> Unit) {
    val p = LocalPalette.current
    var info by remember { mutableStateOf<Pair<SurahEntity, Int>?>(null) }
    LaunchedEffect(vm.lastPage) { info = vm.repo.pageInfo(vm.lastPage) }
    var input by remember { mutableStateOf("") }
    val bookmarks by vm.bookmarks.collectAsState(emptyList())

    Column(Modifier.fillMaxSize()) {
        Header(S.appName, S.tagline)
        Column(Modifier.padding(horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(22.dp)) {
            NeuBox(Modifier.fillMaxWidth(), radius = 26.dp, depth = 9.dp, onClick = { openReader(vm.lastPage) }) {
                Column(Modifier.padding(22.dp)) {
                    Text(S.continueReading, color = p.sub, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        info?.first?.let { "${S.surahWord} ${it.englishName}" } ?: "${S.page} ${vm.lastPage.toBn()}",
                        color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "${S.page} ${vm.lastPage.toBn()}" + (info?.let { " · ${S.juzWord} ${it.second.toBn()}" } ?: ""),
                        color = p.accent, fontSize = 14.sp
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                NeuBox(Modifier.weight(1f).height(54.dp), radius = 27.dp, depth = 5.dp, inset = true) {
                    BasicTextField(
                        value = input,
                        onValueChange = { v -> input = v.filter { it.isDigit() }.take(3) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = TextStyle(color = p.text, fontSize = 16.sp),
                        cursorBrush = SolidColor(p.accent),
                        modifier = Modifier.align(Alignment.CenterStart).padding(horizontal = 22.dp).fillMaxWidth(),
                        decorationBox = { inner ->
                            if (input.isEmpty()) Text(S.goToPage, color = p.sub, fontSize = 14.sp)
                            inner()
                        }
                    )
                }
                NeuBox(Modifier.height(54.dp).width(84.dp), radius = 27.dp, onClick = {
                    input.toIntOrNull()?.takeIf { it in 1..QuranRepository.TOTAL_PAGES }?.let(openReader)
                }) {
                    Text(S.go, color = p.accent, fontWeight = FontWeight.SemiBold, modifier = Modifier.align(Alignment.Center))
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                StatTile("৬০৪", S.page, Modifier.weight(1f))
                StatTile("১১৪", S.surahWord, Modifier.weight(1f))
                StatTile(bookmarks.size.toBn(), S.tabBookmark, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun StatTile(value: String, label: String, modifier: Modifier) {
    val p = LocalPalette.current
    NeuBox(modifier.height(86.dp), radius = 20.dp, depth = 6.dp) {
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = p.accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(label, color = p.sub, fontSize = 12.sp)
        }
    }
}

// ───────────────────────── Surah list ─────────────────────────

@Composable
fun SurahScreen(vm: AppViewModel, openReader: (Int) -> Unit) {
    val p = LocalPalette.current
    val all by vm.surahs.collectAsState(emptyList())
    var q by remember { mutableStateOf("") }
    val list = remember(all, q) {
        val t = q.trim().lowercase()
        if (t.isEmpty()) all else all.filter {
            it.surah.englishName.lowercase().contains(t) ||
                it.surah.englishTranslation.lowercase().contains(t) ||
                it.surah.number.toString() == t
        }
    }
    Column(Modifier.fillMaxSize()) {
        Header(S.tabSurah)
        NeuBox(Modifier.padding(horizontal = 24.dp).fillMaxWidth().height(52.dp), radius = 26.dp, depth = 5.dp, inset = true) {
            BasicTextField(
                value = q, onValueChange = { q = it }, singleLine = true,
                textStyle = TextStyle(color = p.text, fontSize = 15.sp),
                cursorBrush = SolidColor(p.accent),
                modifier = Modifier.align(Alignment.CenterStart).padding(horizontal = 22.dp).fillMaxWidth(),
                decorationBox = { inner ->
                    if (q.isEmpty()) Text(S.searchSurah, color = p.sub, fontSize = 14.sp)
                    inner()
                }
            )
        }
        LazyColumn(
            contentPadding = PaddingValues(24.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            items(list, key = { it.surah.number }) { row ->
                val s = row.surah
                NeuBox(Modifier.fillMaxWidth(), radius = 20.dp, onClick = { openReader(row.startPage) }) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        NeuBox(Modifier.size(44.dp), radius = 22.dp, depth = 4.dp, inset = true) {
                            Text(s.number.toBn(), color = p.accent, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Center))
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(s.englishName, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                            Text(
                                "${s.englishTranslation} · ${s.ayahCount.toBn()} ${S.ayahWord} · " +
                                    (if (s.revelationType.equals("Meccan", true)) S.meccan else S.medinan),
                                color = p.sub, fontSize = 12.sp
                            )
                        }
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                            Text(s.name, color = p.text, fontSize = 20.sp)
                        }
                    }
                }
            }
        }
    }
}

// ───────────────────────── Juz grid ─────────────────────────

@Composable
fun JuzScreen(vm: AppViewModel, openReader: (Int) -> Unit) {
    val p = LocalPalette.current
    val juzs by vm.juzs.collectAsState(emptyList())
    Column(Modifier.fillMaxSize()) {
        Header(S.tabJuz)
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            contentPadding = PaddingValues(24.dp),
            horizontalArrangement = Arrangement.spacedBy(18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            items(juzs, key = { it.juz }) { j ->
                NeuBox(Modifier.fillMaxWidth().height(92.dp), radius = 20.dp, onClick = { openReader(j.startPage) }) {
                    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(j.juz.toBn(), color = p.accent, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Text("${S.page} ${j.startPage.toBn()}", color = p.sub, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

// ───────────────────────── Bookmarks ─────────────────────────

@Composable
fun BookmarkScreen(vm: AppViewModel, openReader: (Int) -> Unit) {
    val p = LocalPalette.current
    val marks by vm.bookmarks.collectAsState(emptyList())
    val surahs by vm.surahs.collectAsState(emptyList())
    Column(Modifier.fillMaxSize()) {
        Header(S.tabBookmark)
        if (marks.isEmpty()) {
            Text(S.noBookmarks, color = p.sub, fontSize = 14.sp, lineHeight = 21.sp, modifier = Modifier.padding(horizontal = 28.dp))
        }
        LazyColumn(contentPadding = PaddingValues(24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            items(marks, key = { it.page }) { m ->
                val name = surahs.firstOrNull { it.surah.number == m.surah }?.surah?.englishName
                NeuBox(Modifier.fillMaxWidth(), radius = 20.dp, onClick = { openReader(m.page) }) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Bookmark, null, tint = p.accent)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${S.page} ${m.page.toBn()}", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                            if (name != null) Text("${S.surahWord} $name", color = p.sub, fontSize = 12.sp)
                        }
                        NeuBox(Modifier.size(38.dp), radius = 19.dp, depth = 4.dp, onClick = { vm.removeBookmark(m.page) }) {
                            Icon(Icons.Rounded.Close, null, tint = p.sub, modifier = Modifier.size(18.dp).align(Alignment.Center))
                        }
                    }
                }
            }
        }
    }
}

// ───────────────────────── Settings ─────────────────────────

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val p = LocalPalette.current
    Column(Modifier.fillMaxSize()) {
        Header(S.tabSettings)
        Column(Modifier.padding(horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
            SettingRow(S.dark) { NeuSwitch(vm.dark) { vm.setDark(it) } }
            SettingRow(S.translation) { NeuSwitch(vm.showTranslation) { vm.setTranslation(it) } }
            SettingRow(S.keepOn) { NeuSwitch(vm.keepScreenOn) { vm.setKeepScreenOn(it) } }

            NeuBox(Modifier.fillMaxWidth(), radius = 20.dp) {
                Column(Modifier.padding(18.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(S.fontSize, color = p.text, fontSize = 15.sp)
                        Text(vm.fontSize.toInt().toBn(), color = p.accent, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = vm.fontSize, onValueChange = { vm.setFontSize(it) },
                        valueRange = 22f..46f,
                        colors = SliderDefaults.colors(
                            thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.dark
                        )
                    )
                    Box(Modifier.fillMaxWidth().padding(top = 6.dp), contentAlignment = Alignment.Center) {
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                            Text("بِسْمِ ٱللَّهِ ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ", color = p.text, fontSize = vm.fontSize.sp)
                        }
                    }
                }
            }

            NeuBox(Modifier.fillMaxWidth().height(52.dp), radius = 26.dp, onClick = { vm.redownload() }) {
                Text(S.redownload, color = p.accent, fontWeight = FontWeight.SemiBold, modifier = Modifier.align(Alignment.Center))
            }
            Text(S.textSource, color = p.sub, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SettingRow(label: String, trailing: @Composable () -> Unit) {
    val p = LocalPalette.current
    NeuBox(Modifier.fillMaxWidth(), radius = 20.dp) {
        Row(Modifier.padding(horizontal = 18.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = p.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
            trailing()
        }
    }
}

// ───────────────────────── Bottom bar ─────────────────────────

data class TabItem(val label: String, val icon: ImageVector)

val Tabs = listOf(
    TabItem(S.tabHome, Icons.Rounded.Home),
    TabItem(S.tabSurah, Icons.Rounded.MenuBook),
    TabItem(S.tabJuz, Icons.Rounded.Layers),
    TabItem(S.tabBookmark, Icons.Rounded.Bookmark),
    TabItem(S.tabSettings, Icons.Rounded.Settings)
)

@Composable
fun NeuBottomBar(selected: Int, onSelect: (Int) -> Unit) {
    val p = LocalPalette.current
    NeuBox(Modifier.padding(horizontal = 18.dp, vertical = 12.dp).fillMaxWidth(), radius = 28.dp, depth = 8.dp) {
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            Tabs.forEachIndexed { i, t ->
                NeuBox(Modifier.size(52.dp), radius = 18.dp, depth = 4.dp, inset = i == selected, onClick = { onSelect(i) }) {
                    Icon(
                        t.icon, t.label,
                        tint = if (i == selected) p.accent else p.sub,
                        modifier = Modifier.size(24.dp).align(Alignment.Center)
                    )
                }
            }
        }
    }
}
