package com.afnan.alquran.data

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("alquran_prefs", Context.MODE_PRIVATE)

    var dark: Boolean
        get() = sp.getBoolean("dark", false)
        set(v) = sp.edit().putBoolean("dark", v).apply()

    var showTranslation: Boolean
        get() = sp.getBoolean("translation", false)
        set(v) = sp.edit().putBoolean("translation", v).apply()

    var fontSize: Float
        get() = sp.getFloat("fontSize", 30f)
        set(v) = sp.edit().putFloat("fontSize", v).apply()

    var lastPage: Int
        get() = sp.getInt("lastPage", 1)
        set(v) = sp.edit().putInt("lastPage", v).apply()

    var keepScreenOn: Boolean
        get() = sp.getBoolean("keepOn", true)
        set(v) = sp.edit().putBoolean("keepOn", v).apply()
}
