package com.afnan.alquran.ui

/** All UI text in one place (Bengali). Swap this object to localise. */
object S {
    const val appName = "আল-কুরআন"
    const val tagline = "পড়ুন, ভাবুন, মেনে চলুন"
    const val tabHome = "হোম"
    const val tabSurah = "সূরা"
    const val tabJuz = "পারা"
    const val tabBookmark = "বুকমার্ক"
    const val tabSettings = "সেটিংস"

    const val dlTitle = "প্রথমবার সেটআপ"
    const val dlBody = "কুরআনের আরবি টেক্সট ও বাংলা অনুবাদ একবার ডাউনলোড হবে। এরপর অ্যাপ সম্পূর্ণ অফলাইনে চলবে।"
    const val dlStart = "ডাউনলোড শুরু করুন"
    const val dlRetry = "আবার চেষ্টা করুন"
    val dlStages = listOf("আরবি টেক্সট আনা হচ্ছে…", "বাংলা অনুবাদ আনা হচ্ছে…", "ডেটাবেসে সংরক্ষণ হচ্ছে…")
    const val dlError = "ডাউনলোড ব্যর্থ"

    const val continueReading = "শেষ পড়া থেকে চালিয়ে যান"
    const val goToPage = "পৃষ্ঠায় যান (১–৬০৪)"
    const val go = "যান"
    const val page = "পৃষ্ঠা"
    const val surahWord = "সূরা"
    const val juzWord = "পারা"
    const val ayahWord = "আয়াত"
    const val meccan = "মক্কী"
    const val medinan = "মাদানী"
    const val searchSurah = "সূরা খুঁজুন (নাম বা নম্বর)"

    const val noBookmarks = "কোনো বুকমার্ক নেই। পড়ার সময় উপরের বুকমার্ক আইকনে চাপ দিন।"

    const val dark = "ডার্ক মোড"
    const val translation = "বাংলা অনুবাদ দেখান"
    const val fontSize = "আরবি ফন্ট সাইজ"
    const val keepOn = "পড়ার সময় স্ক্রিন জাগিয়ে রাখুন"
    const val redownload = "ডেটা আবার ডাউনলোড করুন"
    const val textSource = "টেক্সট: api.alquran.cloud (quran-uthmani, bn.bengali)"
}

private val bnDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
private val arDigits = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')

fun Int.toBn(): String = toString().map { bnDigits[it - '0'] }.joinToString("")
fun Int.toArabicDigits(): String = toString().map { arDigits[it - '0'] }.joinToString("")
