# AlQuranNeu
Neumorphic Quran reader (Kotlin + Compose). বিস্তারিত: `PLAN.md`

Build: Android Studio (JDK 17) দিয়ে খুলে Run, অথবা `gradle wrapper --gradle-version 8.9 && ./gradlew assembleDebug`.
প্রথমবার ইন্টারনেট লাগবে (টেক্সট ডাউনলোড), তারপর অফলাইন।

## GitHub Actions
`.github/workflows/build.yml` — main/master-এ push বা manual run করলে debug APK বানিয়ে GitHub Release (`build-N`) হিসেবে দেয়; সর্বশেষ ৫টি রাখে।
সাইন করা release: Run workflow → `release` টিক দিন এবং Secrets-এ দিন `AQ_KEYSTORE_B64`, `AQ_KS_PASS`, `AQ_KEY_ALIAS`, `AQ_KEY_PASS`।
সোর্স রিপোতে আনজিপড বা `.zip` — দুভাবেই চলে। (zip রাখলে নতুন zip-ই আগের ফাইল ওভাররাইট করে।)
