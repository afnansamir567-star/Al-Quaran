# AlQuranNeu
Neumorphic Quran reader (Kotlin + Compose). বিস্তারিত: `PLAN.md`

Build: Android Studio (JDK 17) দিয়ে খুলে Run, অথবা `gradle wrapper --gradle-version 8.9 && ./gradlew assembleDebug`.
প্রথমবার ইন্টারনেট লাগবে (টেক্সট ডাউনলোড), তারপর অফলাইন।

## GitHub Actions
`.github/workflows/android.yml` — প্রতি push/PR-এ debug APK বানিয়ে Artifacts-এ রাখে।
সাইন করা release APK: `v1.0.0`-এর মতো ট্যাগ পুশ করুন এবং রিপোজিটরি Secrets-এ দিন:
`KEYSTORE_BASE64` (`base64 -w0 release.jks`), `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`।
